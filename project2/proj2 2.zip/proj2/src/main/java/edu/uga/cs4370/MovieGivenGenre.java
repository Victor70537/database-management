package edu.uga.cs4370;

public class MovieGivenGenre {
    
    private String movieTitle;
    private String genreTitle;

    public MovieGivenGenre (String movieTitle, String genreTitle) {
        this.movieTitle = movieTitle;
        this.genreTitle = genreTitle;
    }

}
