Project 2: 

Run App.java with F5 to host the website. 
Make sure to run ddl.sql by running "docker-compose up" in the docker folder. 
Make sure the docker container is up and running before running App.java.

Access the website by visiting "localhost:8080/dynamic/reviews" and "localhost:8080/dynamic/login". 


