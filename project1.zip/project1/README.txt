Project 1 completed by Alex Fritz, Victor Qiu, Althea Pamintawan, and Sanjay DK


To compile, execute the following command from this directory:

javac -d bin src/uga/cs4370/mydb/impl/*.java src/uga/cs4370/mydb/*.java


To run, execute the following command from this directory:

java -cp bin uga.cs4370.mydb.impl.Driver